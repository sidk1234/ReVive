//
//  AppConfigStore.swift
//  Recyclability
//

import Foundation
import Combine

struct AppConfig: Codable, Equatable {
    let supabaseURL: String
    let supabaseAnonKey: String
    let googleIOSClientID: String
    let googleWebClientID: String
    let googleReversedClientID: String
}

enum AppConfigCache {
    private static let storageKey = "recai.app.config"

    static func load() -> AppConfig? {
        guard let data = UserDefaults.standard.data(forKey: storageKey) else { return nil }
        return try? JSONDecoder().decode(AppConfig.self, from: data)
    }

    static func save(_ config: AppConfig) {
        guard let data = try? JSONEncoder().encode(config) else { return }
        UserDefaults.standard.set(data, forKey: storageKey)
    }

    static func clear() {
        UserDefaults.standard.removeObject(forKey: storageKey)
    }
}

enum BootstrapConfig {
    static var edgeBaseURL: URL? {
        guard
            let value = Bundle.main.object(forInfoDictionaryKey: "EDGE_BASE_URL") as? String,
            !value.isEmpty
        else { return nil }
        return URL(string: value)
    }
}

@MainActor
final class AppConfigStore: ObservableObject {
    @Published private(set) var config: AppConfig?
    @Published private(set) var isLoading = false
    @Published var errorMessage: String?

    func load(force: Bool = false) async {
        let cached = AppConfigCache.load()
        if !force, let cached {
            config = cached
        }

        guard let baseURL = BootstrapConfig.edgeBaseURL else {
            if config == nil {
                errorMessage = "Missing edge base URL."
            }
            return
        }

        if let cached,
           let cachedHost = URL(string: cached.supabaseURL)?.host,
           let baseHost = baseURL.host,
           cachedHost != baseHost {
            AppConfigCache.clear()
            config = nil
        }

        let endpoint = baseURL.appendingPathComponent("functions/v1/rec-ai-config")
        isLoading = true
        defer { isLoading = false }

        do {
            let (data, response) = try await URLSession.shared.data(from: endpoint)
            guard let http = response as? HTTPURLResponse else {
                errorMessage = "Invalid config response."
                return
            }
            guard (200...299).contains(http.statusCode) else {
                let message = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
                errorMessage = "Config fetch failed (\(http.statusCode)): \(message)"
                return
            }

            let decoded = try JSONDecoder().decode(RemoteConfigResponse.self, from: data)
            let config = AppConfig(
                supabaseURL: decoded.supabaseURL ?? "",
                supabaseAnonKey: decoded.supabaseAnonKey ?? "",
                googleIOSClientID: decoded.googleIOSClientID ?? "",
                googleWebClientID: decoded.googleWebClientID ?? "",
                googleReversedClientID: decoded.googleReversedClientID ?? ""
            )

            guard !config.supabaseURL.isEmpty, !config.supabaseAnonKey.isEmpty else {
                errorMessage = "Config missing Supabase settings."
                return
            }

            AppConfigCache.save(config)
            self.config = config
            errorMessage = nil
        } catch {
            if let cached = AppConfigCache.load() {
                config = cached
            } else {
                errorMessage = "Config fetch failed."
            }
        }
    }
}

private struct RemoteConfigResponse: Decodable {
    let supabaseURL: String?
    let supabaseAnonKey: String?
    let googleIOSClientID: String?
    let googleWebClientID: String?
    let googleReversedClientID: String?

    private enum CodingKeys: String, CodingKey {
        case supabaseURL = "supabase_url"
        case supabaseAnonKey = "supabase_anon_key"
        case googleIOSClientID = "google_ios_client_id"
        case googleWebClientID = "google_web_client_id"
        case googleReversedClientID = "google_reversed_client_id"
    }
}
