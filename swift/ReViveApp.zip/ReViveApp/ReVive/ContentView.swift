//
//  ContentView.swift
//  Recyclability
//
//  Created by Sidharth Kumar on 1/24/26.
//
import SwiftUI

struct ContentView: View {
    var body: some View {
        MainTabView()
    }
}

#Preview {
    ContentView()
}
